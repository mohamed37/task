<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Role;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;



class RolesController extends Controller
{
    public function __construct()
    {
        return $this->middleware([
            'auth:admin',
            'can:create-roles',
            'can:read-roles',
            'can:update-roles',
            'can:delete-roles',
        ]);
    }

    public function index()
    {
        $roles = Role::paginate();
        return view('Dashboard.Roles.index',compact('roles'));
    }
    
    public function create()
    {
        return view('Dashboard.Roles.create');
    }

    public function store(Request $request)
    {
        try{
            //validation 
             $validator = Validator::make($request->all(),[
                'name' => 'required|string|max:255',
                'slug' => 'required|string|max:255',
             ]);
             
             if($validator->fails())
             {
                return back()->withErrors($validator)->withInput();
             }

             Role::create($request);

             return redirect('roles.index');

        }catch(\Throwable $th){
            abort(404);
        }
    }

    public function edit($id)
    {
        $roleId = Crypt::decrypt($id);
        $role = Role::findOrFail($roleId);
        
        return view('Dashboard.Roles.edit', compact('role'));
    }

    public function update(Request $request)
    {
        try{
            $role = Role::findOrFail($request->id);

            $validator = Validator::make($request->all(),[
                'name' => 'required|string|max:255',
                'slug' => 'required|string|max:255',
             ]);
             
             if($validator->fails())
             {
                return back()->withErrors($validator)->withInput();
             }

             $role->update($request);

             return redirect('roles.index');
            
        }catch(\Throwable $th){
            abort(404);
        }   
    }

    public function destroy(Request $request)
    {
        $role = Role::findOrFail($request->id)->delete();
        return back();
    }

    public function RoleToAdmin()
    {
        $roles = Role::get();
        $users = User::get();
        
        return view('Dashboard.Admins.create',compact('roles', 'users'));
    }
    public function storeRoleToAdmin(Request $request)
    {
        try{
            DB::beginTransaction();
            //validation 
             $validator = Validator::make($request->all(),[
                'admin_id' => 'required|exists:admins,id,'.$request->admin_id,
                'role_id' => 'required|exists:rols,id,'.$request->role_id,
              ]);
             
             if($validator->fails())
             {
                return back()->withErrors($validator)->withInput();
             }

              $request->admin_id->permissions()->attach([
                    'admin_id' => $request->admin_id,
                    'role_id' => $request->role_id 
                ]);
             DB::commit();
         
             return redirect('roles.index');

        }catch(\Throwable $th){
            DB::rollBack();
       
            abort(404);
        }
    }
    public function storePermissionToRole(Request $request)
    {
        try{
            DB::beginTransaction();
            //validation 
             $validator = Validator::make($request->all(),[
                'admin_id' => 'required|exists:admins,id,'.$request->admin_id,
                'role_id' => 'required|exists:roles,id,'.$request->role_id,
                'permission_id' => 'required|exists:permissions,id,'.$request->permission_id,
              ]);
             
             if($validator->fails())
             {
                return back()->withErrors($validator)->withInput();
             }

             $request->admin_id->roles()->sync([
                    'admin_id' => $request->admin_id,
                    'role_id' => $request->role_id
                ]);

              $request->admin_id->permissions()->attach([
                    'admin_id' => $request->role_id,
                    'permission_id' => $request->permission_id 
                ]);
             DB::commit();
         
             return redirect('roles.index');

        }catch(\Throwable $th){
            DB::rollBack();
       
            abort(404);
        }
    }


}
