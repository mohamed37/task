<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Admin;
use App\Models\Permission;
use Illuminate\Auth\Access\HandlesAuthorization;

class PermissionsPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function hasAbility(Role $role, Permission $permissions)
    {
        if(!$role){
            return false;
        }
     
        foreach($role->permissions as $key => $ability)
        {
            if(is_array($permissions) && in_array($permission, $permissions)){
                return true;
             }else if(is_array($permissions) && strcmp($permissions,$permission = 0)) {
                return true;
             }
        } 
            return false; 
        
    }

}
